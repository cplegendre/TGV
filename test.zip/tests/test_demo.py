from __future__ import annotations

import json
from pathlib import Path

import pytest

from tgv.cli import main
from tgv.demo import _load_tasks, render_demo, run_demo
from tgv.exceptions import TGVError
from tgv.models import Route


def test_demo_internal_and_artifacts(tmp_path: Path) -> None:
    result = run_demo(output=tmp_path)
    assert result.success
    assert result.tasks_processed == 50
    assert result.matched_routes == 50
    assert result.local_routes == 30
    assert result.frontier_routes == 20
    assert result.safety_escalations == 10
    assert result.local_share >= 0
    assert result.savings_tokens >= 0
    assert result.savings_ratio >= 0
    assert (tmp_path / "report.json").is_file()
    records = list((tmp_path / "telemetry").glob("*.jsonl"))
    assert len(records) == 50
    assert '"synthetic":true' in records[0].read_text(encoding="utf-8")
    assert '"source":"tgv_demo"' in records[0].read_text(encoding="utf-8")
    assert all(
        task.actual_route == Route.FRONTIER_DEEP
        for task in result.tasks
        if task.task_id
        in {
            "authentication-change",
            "destructive-migration",
            "ambiguous-redesign",
            "authorization-redesign",
            "credential-rotation",
            "microservices-split",
            "concurrency-fix",
            "security-architecture",
            "delete-production-data",
            "unknown-full-redesign",
        }
    )


def test_demo_no_report(tmp_path: Path) -> None:
    result = run_demo(output=tmp_path, generate_report=False)
    assert not result.report_generated
    assert not (tmp_path / "report.json").exists()


def test_cli_demo_json_and_alias(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    main(["demo", "--json", "--output", str(tmp_path / "one")])
    first = json.loads(capsys.readouterr().out)
    main(["--demo", "--json", "--output", str(tmp_path / "two")])
    second = json.loads(capsys.readouterr().out)
    assert first["success"] is True
    assert second["tasks"] == first["tasks"]


def test_demo_keep_data_and_default_cleanup(capsys: pytest.CaptureFixture[str]) -> None:
    kept = run_demo(keep_data=True)
    assert kept.output_directory is not None
    kept_path = Path(kept.output_directory)
    assert kept_path.is_dir()
    default = run_demo()
    assert default.output_directory is None
    text = render_demo(kept)
    assert "TGV synthetic demo" in text
    assert "Workspace:" in text
    import shutil

    shutil.rmtree(kept_path)


def test_demo_malformed_tasks(tmp_path: Path) -> None:
    (tmp_path / "sample-repo").mkdir()
    (tmp_path / "tasks.json").write_text("not-json", encoding="utf-8")
    with pytest.raises(TGVError, match="Cannot parse demo tasks"):
        run_demo(output=tmp_path / "out", assets_root=tmp_path)


def test_demo_route_mismatch(tmp_path: Path) -> None:
    source = Path(__file__).parents[1] / "src" / "tgv" / "demo_assets"
    import shutil

    assets = tmp_path / "assets"
    shutil.copytree(source, assets)
    tasks = json.loads((assets / "tasks.json").read_text(encoding="utf-8"))
    tasks[0]["expected_route"] = "frontier_deep"
    (assets / "tasks.json").write_text(json.dumps(tasks), encoding="utf-8")
    result = run_demo(output=tmp_path / "out", assets_root=assets)
    assert not result.success
    assert result.failed_routes == 1


def test_load_tasks_rejects_invalid_shape(tmp_path: Path) -> None:
    path = tmp_path / "tasks.json"
    path.write_text("{}", encoding="utf-8")
    with pytest.raises(TGVError, match="JSON array"):
        _load_tasks(path)
    path.write_text('[{"id": 1}]', encoding="utf-8")
    with pytest.raises(TGVError, match="requires string"):
        _load_tasks(path)


def test_demo_missing_repository(tmp_path: Path) -> None:
    (tmp_path / "tasks.json").write_text("[]", encoding="utf-8")
    with pytest.raises(TGVError, match="cannot be located"):
        run_demo(output=tmp_path / "out", assets_root=tmp_path)


def test_demo_unknown_route(tmp_path: Path) -> None:
    source = Path(__file__).parents[1] / "src" / "tgv" / "demo_assets"
    import shutil

    assets = tmp_path / "assets-unknown"
    shutil.copytree(source, assets)
    tasks = json.loads((assets / "tasks.json").read_text(encoding="utf-8"))
    tasks[0]["expected_route"] = "unknown"
    (assets / "tasks.json").write_text(json.dumps(tasks), encoding="utf-8")
    with pytest.raises(TGVError, match="Unknown expected route"):
        run_demo(output=tmp_path / "out-unknown", assets_root=assets)


def test_demo_rejects_negative_report(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "tgv.demo.basic_value_report",
        lambda _path: {"local_share": -1.0, "savings_tokens": 0, "savings_ratio": 0.0},
    )
    with pytest.raises(TGVError, match="Invalid demo report field"):
        run_demo(output=tmp_path / "negative")
