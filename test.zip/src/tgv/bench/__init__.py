"""Deterministic local benchmark runners."""
