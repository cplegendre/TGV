from __future__ import annotations

import json
import shutil
import tempfile
from dataclasses import asdict, dataclass
from importlib import resources
from pathlib import Path
from typing import Any

from tgv.config import default_config
from tgv.efficiency import basic_value_report
from tgv.exceptions import TGVError
from tgv.models import Route
from tgv.repository import Repository
from tgv.router import Router
from tgv.telemetry import SessionRecorder

_TOKEN_ESTIMATES = {
    Route.LOCAL_FAST: 500,
    Route.LOCAL_CODE: 1500,
    Route.FRONTIER_STANDARD: 0,
    Route.FRONTIER_DEEP: 0,
}


@dataclass(frozen=True)
class DemoTaskResult:
    task_id: str
    request: str
    expected_route: Route
    actual_route: Route
    matched: bool
    reason: str | None


@dataclass(frozen=True)
class DemoResult:
    repository: str
    tasks_processed: int
    matched_routes: int
    failed_routes: int
    local_routes: int
    frontier_routes: int
    local_share: float
    savings_tokens: int
    savings_ratio: float
    safety_escalations: int
    report_generated: bool
    output_directory: str | None
    synthetic: bool
    success: bool
    tasks: tuple[DemoTaskResult, ...]

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["tasks"] = [
            {
                **asdict(task),
                "expected_route": task.expected_route.value,
                "actual_route": task.actual_route.value,
            }
            for task in self.tasks
        ]
        return data


def _assets_root() -> Path:
    candidate = resources.files("tgv.demo_assets")
    with resources.as_file(candidate) as path:
        resolved = path.resolve()
    if not resolved.is_dir():
        raise TGVError("Bundled demo repository cannot be located")
    return resolved


def _load_tasks(path: Path) -> list[dict[str, str]]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise TGVError(f"Cannot parse demo tasks: {exc}") from exc
    if not isinstance(raw, list):
        raise TGVError("Demo tasks must be a JSON array")
    tasks: list[dict[str, str]] = []
    for item in raw:
        if not isinstance(item, dict) or not all(
            isinstance(item.get(key), str) for key in ("id", "request", "expected_route")
        ):
            raise TGVError("Each demo task requires string id, request, and expected_route")
        tasks.append({key: item[key] for key in ("id", "request", "expected_route")})
    return tasks


def run_demo(
    *,
    output: Path | None = None,
    keep_data: bool = False,
    generate_report: bool = True,
    assets_root: Path | None = None,
) -> DemoResult:
    assets = (assets_root or _assets_root()).resolve()
    source_repo = assets / "sample-repo"
    tasks_path = assets / "tasks.json"
    if not source_repo.is_dir():
        raise TGVError("Bundled demo repository cannot be located")

    temporary = output is None
    if output is None:  # noqa: SIM108
        workspace = Path(tempfile.mkdtemp(prefix="tgv-demo-"))
    else:
        workspace = output.resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    try:
        repository_path = workspace / "sample-repo"
        shutil.copytree(source_repo, repository_path, dirs_exist_ok=True)
        config = default_config()
        config.routing.use_local_model = False
        config.telemetry.enabled = True
        config.telemetry.log_path = workspace / "telemetry"
        config.intelligence.outcome_database_path = workspace / "outcomes.sqlite3"
        config.repository.index_path = workspace / "index.json"

        repository = Repository(repository_path, config.repository, config.privacy.deny_patterns)
        repository.list_files()
        router = Router(config.routing, provider=None)
        recorder = SessionRecorder(config.telemetry.log_path)
        task_results: list[DemoTaskResult] = []
        safety_escalations = 0
        for task in _load_tasks(tasks_path):
            try:
                expected = Route(task["expected_route"])
            except ValueError as exc:
                raise TGVError(f"Unknown expected route for {task['id']}") from exc
            decision = router.deterministic(task["request"])
            matched = decision.route == expected
            high_risk = "high_risk" in decision.matched_signals
            if high_risk:
                safety_escalations += 1
                if decision.route != Route.FRONTIER_DEEP:
                    matched = False
            recorder.record(
                task["request"],
                decision,
                metadata={"synthetic": True, "source": "tgv_demo", "task_id": task["id"]},
                usage_tokens=_TOKEN_ESTIMATES[decision.route],
            )
            task_results.append(
                DemoTaskResult(
                    task_id=task["id"],
                    request=task["request"],
                    expected_route=expected,
                    actual_route=decision.route,
                    matched=matched,
                    reason=None if matched else "route mismatch",
                )
            )

        metrics = basic_value_report(config.telemetry.log_path)
        for field in ("local_share", "savings_tokens", "savings_ratio"):
            if field not in metrics or float(metrics[field]) < 0:
                raise TGVError(f"Invalid demo report field: {field}")
        if generate_report:
            (workspace / "report.json").write_text(
                json.dumps(metrics, indent=2, sort_keys=True) + "\n", encoding="utf-8"
            )
        local_routes = sum(
            task.actual_route in {Route.LOCAL_FAST, Route.LOCAL_CODE} for task in task_results
        )
        matched_routes = sum(task.matched for task in task_results)
        result = DemoResult(
            repository="demo/sample-repo",
            tasks_processed=len(task_results),
            matched_routes=matched_routes,
            failed_routes=len(task_results) - matched_routes,
            local_routes=local_routes,
            frontier_routes=len(task_results) - local_routes,
            local_share=float(metrics["local_share"]),
            savings_tokens=int(metrics["savings_tokens"]),
            savings_ratio=float(metrics["savings_ratio"]),
            safety_escalations=safety_escalations,
            report_generated=generate_report,
            output_directory=str(workspace) if (keep_data or output is not None) else None,
            synthetic=True,
            success=matched_routes == len(task_results),
            tasks=tuple(task_results),
        )
        return result
    finally:
        if temporary and not keep_data:
            shutil.rmtree(workspace, ignore_errors=True)


def render_demo(result: DemoResult) -> str:
    lines = [
        "TGV synthetic demo",
        "",
        f"Repository: {result.repository}",
        f"Tasks: {result.tasks_processed}",
        "",
    ]
    for index, task in enumerate(result.tasks, 1):
        lines.extend(
            [
                f"{index}. {task.task_id}",
                f"   Expected: {task.expected_route.value}",
                f"   Actual:   {task.actual_route.value}",
                f"   Result:   {'PASS' if task.matched else 'FAIL'}",
                "",
            ]
        )
    lines.extend(
        [
            "Summary",
            "-------",
            f"Tasks processed: {result.tasks_processed}",
            f"Matched routes: {result.matched_routes}",
            f"Local routes: {result.local_routes}",
            f"Frontier routes: {result.frontier_routes}",
            f"Local share: {result.local_share:.1%}",
            f"Estimated token savings: {result.savings_tokens:,}",
            f"Estimated savings ratio: {result.savings_ratio:.2f}",
            f"Safety escalations: {result.safety_escalations}",
            "",
            "Demo completed successfully." if result.success else "Demo failed.",
            "Data source: synthetic illustration",
        ]
    )
    if result.output_directory is not None:
        lines.append(f"Workspace: {result.output_directory}")
    return "\n".join(lines)
