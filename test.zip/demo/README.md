# TGV synthetic demo

This repository, task set, telemetry, and report output are synthetic illustrations intended only to demonstrate TGV workflows. They are not evidence of production savings, routing quality, or model performance.

The sample repository is dependency-free and exists solely for local installation verification.

## Coverage scope

The demo contains 50 deterministic synthetic tasks: 15 `local_fast`, 15 `local_code`, 10 `frontier_standard`, and 10 `frontier_deep`. This is sufficient for installation verification and workflow demonstration, but it is not a statistical benchmark of routing quality or production performance.
