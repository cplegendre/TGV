"""Packaged synthetic demo resources."""
