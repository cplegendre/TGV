# TGV 0.26 release notes

TGV 0.26 standardizes the pre-1.0 version format as `0.xx` and expands a fully local, deterministic synthetic demo for verifying routing, telemetry, reporting, packaging, and mandatory high-risk escalation without API keys, Ollama, network access, TER, or optional dependencies.

All demo data and reported savings are synthetic illustrations and are not evidence of production performance.

## Expanded synthetic demo

The bundled demo now includes 50 deterministic examples: 15 `local_fast`, 15 `local_code`, 10 `frontier_standard`, and 10 `frontier_deep`. This breadth is appropriate for installation verification and workflow demonstration; it is explicitly not a production benchmark.
