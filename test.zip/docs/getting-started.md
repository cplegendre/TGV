# Getting started

1. Install TGV.
2. Run `tgv --demo`.
3. Run `tgv doctor`.
4. Route a real request.
5. Prepare a bundle.
6. Enable telemetry.
7. Run `tgv report`.
8. Start `tgv serve`.

The demo is fully local and synthetic; it requires no API key, Ollama, network access, TER, or other optional dependency.

# Getting started

TGV requires Python 3.11 or newer.

## Install

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install tgv-agent
```

For a source checkout, use `python -m pip install -e .`.

## Check the environment

```bash
tgv doctor
```

The doctor report shows configuration status and availability for Ollama or an OpenAI-compatible endpoint configured for the `fast` role.

## Route a request

```bash
tgv route "Where is authentication configured?" --repo . --explain
```

High-risk security, destructive, concurrency, and architectural work always escalates to `frontier_deep`.

## Prepare a context bundle

```bash
tgv prepare "Fix refresh-token rotation" --repo . --output .tgv/bundles/auth --json
```

The bundle contains an `outcome_task_id` assumption. After review or handoff, record optional human feedback:

```bash
tgv outcomes complete TASK_ID --accepted --repo .
# or
tgv outcomes complete TASK_ID --rejected --repo .
```

Outcome-based scoreboard recommendations are **experimental**. Until the configured minimum sample count is met, TGV returns `fallback_used: true` with a reason and preserves the deterministic route.

## Enable telemetry

```yaml
telemetry:
  enabled: true
  log_path: .tgv/sessions
```

Telemetry is privacy-minimal but includes request text and routing metadata. Review the configuration before enabling it.

## Generate a value report

```bash
tgv report --sessions .tgv/sessions --json
```

The report includes `local_share`, `savings_tokens`, and `savings_ratio`. By default
this works immediately with no extra install, using the coarse token estimates already
recorded in telemetry. For more precise aligned/waste-token scoring, install the optional
TER integration and add `--ter`:

```bash
pip install "tgv-agent[ter]"
tgv report --sessions .tgv/sessions --ter --json
```

## Start the stdio service

```bash
tgv serve --repo . --status-file .tgv/status.json --request-timeout 120
```

Send one JSON object per line:

```json
{"request":"Where is authentication configured?"}
```

Responses are written to stdout. Structured operational logs are written to stderr. Requests are processed sequentially, the status file is replaced atomically, and SIGTERM/SIGINT causes TGV to finish the current request before exiting cleanly.
